package com.formacion.motos.controlador;

import com.formacion.motos.entidades.Cliente;
import com.formacion.motos.servicios.ClienteServicio;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Controller
public class Controlador {

    private final PasswordEncoder passwordEncoder;
    private final ClienteServicio clienteServicio;

    @Autowired
    public Controlador(ClienteServicio clienteServicio, PasswordEncoder passwordEncoder) {
        this.clienteServicio = clienteServicio;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/")
    public String inicio(Model model) {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        Model model,
                        HttpSession session) {

        System.out.println("Intentando loguear con email: " + email);

        if (clienteServicio.verifyUserCredentials(email, password)) {
            Cliente cliente = clienteServicio.encontrarPorEmail(email);

            System.out.println("Cliente encontrado: " + cliente.getNombre());

            String role = "ROLE_" + cliente.getRol();
            List<GrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority(role));

            Authentication auth = new UsernamePasswordAuthenticationToken(cliente.getEmail(), null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);

            System.out.println("✅ Login correcto para: " + cliente.getEmail());

            session.setAttribute("usuarioLogueado", cliente);

            // Redirigir según el rol (ADMIN -> /admin, USER -> /principal)
            if ("ADMIN".equalsIgnoreCase(cliente.getRol())) {
                return "redirect:/admin";
            } else {
                return "redirect:/principal";
            }
        } else {
            System.out.println("Falló la autenticación. Volviendo a login.jsp");
            model.addAttribute("error", "Email o contraseña incorrectos");
            return "login";
        }
    }

    @GetMapping("/admin")
    public String adminPanel(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        System.out.println("🛡 Acceso a /admin con auth: " + auth);

        if (auth == null || !auth.isAuthenticated()) {
            return "redirect:/";
        }

        String email = auth.getName();
        Cliente cliente = clienteServicio.encontrarPorEmail(email);

        if (cliente != null && "ADMIN".equalsIgnoreCase(cliente.getRol())) {
            model.addAttribute("clientes", clienteServicio.findAllUsers());
            return "admin";
        } else {
            return "redirect:/";
        }
    }

    @GetMapping("/principal")
    public String vistaPrincipal(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth == null || !auth.isAuthenticated()) {
            return "redirect:/";
        }

        String email = auth.getName();
        Cliente cliente = clienteServicio.encontrarPorEmail(email);

        if (cliente == null) {
            return "redirect:/";
        }

        model.addAttribute("nombreCliente", cliente.getNombre());
        return "principal";
    
    }

    @GetMapping("/logout")
    public String cerrarSesion() {
        return "redirect:/";
    }

    @GetMapping("/registro")
    public String mostrarRegistro() {
        return "registro";
    }

    @PostMapping("/crearCliente")
    public String procesarRegistro(@RequestParam String nombre,
                                    @RequestParam String apellido1,
                                    @RequestParam(required = false) String apellido2,
                                    @RequestParam String calle,
                                    @RequestParam int numero,
                                    @RequestParam String codigoP,
                                    @RequestParam String localidad,
                                    @RequestParam String poblacion,
                                    @RequestParam String telefono,
                                    @RequestParam String email,
                                    @RequestParam String password,
                                    Model model) {
    	
        // Lista de palabras que prohibimos
        List<String> palabrasProhibidas = List.of(
                "idiota", "estúpido", "tonto", "imbécil", "puta", "ni un brillo pelao","Mamaguevo","cabrón", 
                "gilipollas", "a tu madre la van a sacal pero del estudio del polno", "tarado", "mierda", "idiot", "stupid", "fool", 
                "jerk", "dumbass", "asshole", "bitch", "moron", "prick", "bastard"
            );

        // convierte el nombre a minúsculas y verificar si contiene alguna palabra prohibida
        for (String palabra : palabrasProhibidas) {
            if (nombre.toLowerCase().contains(palabra)) {
                model.addAttribute("mensajeError", "El nombre contiene una palabra inapropiada.");
                return "registro";  // Devolver al formulario con el error
            }
        }

        Cliente cliente = new Cliente();
        cliente.setNombre(nombre);
        cliente.setApellido1(apellido1);
        if (apellido2 != null) cliente.setApellido2(apellido2);
        cliente.setCalle(calle);
        cliente.setNumero(numero);
        cliente.setCodigoP(codigoP);
        cliente.setLocalidad(localidad);
        cliente.setPoblacion(poblacion);
        cliente.setTelefono(telefono);
        cliente.setEmail(email);
        cliente.setPassword(password);
        cliente.setRol("USER");
        cliente.setFechaRegistro(new Date());

        try {
            clienteServicio.guardarCliente(cliente);
            model.addAttribute("mensaje", "Usuario registrado con éxito: " + nombre);
            return "registro";
        } catch (DataIntegrityViolationException e) {
            model.addAttribute("mensajeError", "Error al registrar el usuario. Puede que el correo ya esté en uso.");
            return "registro";
        } catch (Exception e) {
            model.addAttribute("mensajeError", "Ha ocurrido un error inesperado. Intenta de nuevo.");
            return "registro";
        }
    }
    
    @PostMapping("/admin/eliminar")
    public String eliminarCliente(@RequestParam Integer id_cliente) {
       clienteServicio.eliminarPorId(id_cliente);
       return "redirect:/admin";
    }
    @PostMapping("/admin/editar")
    public String editarCliente(@RequestParam Integer id_cliente, Model model) {
       Cliente cliente = clienteServicio.encontrarPorId(id_cliente);
       model.addAttribute("cliente", cliente);
       return "editar-cliente"; // JSP que te puedo generar ahora
    }
    
    @PostMapping("/admin/actualizar")
    public String actualizarCliente(@RequestParam Integer id_cliente,
                                    @RequestParam String nombre,
                                    @RequestParam String apellido1,
                                    @RequestParam(required = false) String apellido2,
                                    @RequestParam String email,
                                    @RequestParam String telefono,
                                    @RequestParam String rol,
                                    @RequestParam String calle,
                                    @RequestParam String numero,
                                    @RequestParam String localidad,
                                    @RequestParam String codigoP, 
                                    @RequestParam String poblacion,
                                    Model model) {

        Cliente cliente = clienteServicio.encontrarPorId(id_cliente);
        if (cliente != null) {
            cliente.setNombre(nombre);
            cliente.setApellido1(apellido1);
            cliente.setApellido2(apellido2);
            cliente.setEmail(email);
            cliente.setTelefono(telefono);
            cliente.setRol(rol);
            cliente.setCalle(calle);
            cliente.setNumero(Integer.parseInt(numero)); // el campo es int
            cliente.setLocalidad(localidad);
            cliente.setCodigoP(codigoP);
            cliente.setPoblacion(poblacion);
            clienteServicio.guardarCliente(cliente);
        }

        return "redirect:/admin";
    }

    @Controller
    public class ErrorControllerCustom {

        @GetMapping("/403")
        public String accesoDenegado() {
            return "403";
        }
    }
}
