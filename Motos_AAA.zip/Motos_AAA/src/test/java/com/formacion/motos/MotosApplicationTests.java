package com.formacion.motos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotosApplicationTests {

	@Test
	void contextLoads() {
	}

}
